import React from "react";
import ReactDOM from "react-dom";
import { csv, json } from "d3";
import "./styles.css";
import { SymbolMap } from "./symbolMap";
import { SymmetricBarChart } from "./charts";
import { Tooltip } from "./tooltip";
import * as d3 from 'd3';
import { Scales } from "./scale";
import { Legend } from "./legend";
import { Map } from './map';
import { BarChart } from './charts';



const map_json = 'https://gist.githubusercontent.com/Evan-Unofficial/db447b2d0029ba68e3a846cc007c379f/raw/b0be5e852527720cc0fdd4ee12bd5af6752345e4/gz_2010_us_040_00_5m.json';
const map_and_bar = 'https://gist.githubusercontent.com/Evan-Unofficial/7e72bdb94e5c0fe700b680dcc5404f66/raw/70faf9eeb3d84a7685502b0a9acb9443fb2fa730/new_map_and_bar.csv';

function use_map_and_bar_data(csvPath){
    const [dataAll, setData] = React.useState(null);
    React.useEffect(() => {
        csv(csvPath).then(data => {
            data.forEach(d => {
                d.total_case = +d.total_case;
                d.unarmed_case = +d.unarmed_case;
            });
            setData(data);
        });
    }, []);
    return dataAll;
}

function useMap(jsonPath) {
    const [data, setData] = React.useState(null);
    React.useEffect(() => {
        json(jsonPath).then(geoJsonData => {
            setData(geoJsonData);
        })
    }, []);
    return data;
}

function PoliceShootings(){
    const [year, setYear] = React.useState('2');
    const [selectedState, setSelectedState] = React.useState(null);
    console.log(selectedState);

    // const WIDTH = 1200;
    // const HEIGHT = 800;
    // const margin = { top: 20, right: 40, bottom: 160, left: 40, gap:40 };
    // const innerWidth = WIDTH - margin.left - margin.right;
    // const innerHeight = HEIGHT - margin.top - margin.bottom;

    const map_and_bar_data = use_map_and_bar_data(map_and_bar);
    const map = useMap(map_json);
    const YEAR = ['2015', '2016', '2017', '2018', '2019'];
    
        if (!map || !map_and_bar_data) {
            return <pre>Loading...</pre>;
        };

    const changeHandler = (event) => {
        setYear(event.target.value);
    }
    const data = map_and_bar_data.filter( d => {
        return d.year === YEAR[year];
    });

const width = 1200;
const height = 300;
const startRange = [0, d3.max(data, d => d.total_case)];
const colorRange = [d3.interpolateReds(0), d3.interpolateReds(1)];
const colormap = Scales.colormapLinear(startRange, colorRange);

return <div>
    <div>
        <input key="slider" type='range' min='0' max='4' value={year} step='1' onChange={changeHandler} />
        <input key="monthText" type="text" value={YEAR[year]} readOnly />
    </div>
    <svg width={width + 100} height={height + 100}>
            <g>
                <Map map={map} data={data} height={height} width={600} colormap={colormap} selectedState={selectedState} setSelectedState={setSelectedState} />
                <Legend x={100} y={height + 50} width={width / 3} height={10} numberOfTicks={6} rangeOfValues={[0, d3.max(data, d => d.total_case)]} colormap={colormap} />
                <g transform={`translate(${700}, ${0})`}><BarChart offsetX={0} offsetY={20} data={data} height={height} width={400} selectedState={selectedState} setSelectedState={setSelectedState}/></g>
            </g>
        </svg>
        </div>
        
}

ReactDOM.render(<PoliceShootings/ >, document.getElementById("root"));