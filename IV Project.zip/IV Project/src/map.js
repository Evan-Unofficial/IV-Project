import React from "react";
import { geoPath, geoMercator } from "d3-geo";
import { scaleLinear, min, max } from "d3";
import * as d3 from 'd3';

export function Map(props) {
    const {map, data, height, width, colormap, selectedState, setSelectedState} = props;

    const MouseEnter = (d) => {
        setSelectedState(d.state);
        
    };
    const MouseOut = () => {
        setSelectedState(null)
    };
    const getColor = (d) => {
        if (d.state === selectedState) {
            return 'steelblue';
        } else {
            return colormap(d.total_case);
        }
    };

    const projection = d3.geoAlbersUsa()
				   .translate([width/2, height/2])    // translate to center of screen
				   .scale([1000]);          // scale things down so see entire US
    const path = d3.geoPath(projection.fitSize([width, height], map));

    return <svg width={width} height={height} >
    {map.features.map( feature => {
        const state = data.filter( d => (d.state === feature.properties.NAME));
                if (state[0]){
                    return <path key={feature.properties.NAME+"boundary"} className={"boundary"} 
                d={path(feature)} style={{fill:getColor(state[0])} } 
                onMouseEnter={() => MouseEnter(state[0])} onMouseOut={() => MouseOut(state[0])}/>
                 } else {
                    return <path key={feature.properties.NAME+"boundary"} className={"boundary"} 
                d={path(feature)}/>} 
                    })}
        </svg> 
}